/*
 * HttpRequest.cpp
 *
 *  Created on: Jan 18, 2017
 *      Author: liyuanqi
 */

#include "HttpProtocol.h"

struct HttpRequest r1;
